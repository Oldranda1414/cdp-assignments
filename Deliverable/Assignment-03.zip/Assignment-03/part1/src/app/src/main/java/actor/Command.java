package actor;
public interface Command {}