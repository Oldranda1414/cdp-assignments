#!/bin/bash

go run go/main.go go/oracle.go go/oracleStates.go go/player.go go/playerStates.go go/utils.go $@