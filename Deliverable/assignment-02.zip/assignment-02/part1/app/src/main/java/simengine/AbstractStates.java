package simengine;

import utils.RWTreeMonitor;

public class AbstractStates<T extends AbstractEnvironment<? extends AbstractAgent>> extends RWTreeMonitor<AgentState<T>> {
}
