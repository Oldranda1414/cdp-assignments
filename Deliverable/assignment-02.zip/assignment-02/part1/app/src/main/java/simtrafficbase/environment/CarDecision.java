package simtrafficbase.environment;

public enum CarDecision {
    ACCELERATING,
    DECELERATING,
    CONSTANT_SPEED
}
