package macropart1.simengine;

import macropart1.utils.RWTreeMonitor;

public class AbstractStates<T extends AbstractEnvironment<? extends AbstractAgent>> extends RWTreeMonitor<AgentState<T>> {
}
