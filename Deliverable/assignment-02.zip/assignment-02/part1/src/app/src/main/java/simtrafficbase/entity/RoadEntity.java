package macropart1.simtrafficbase.entity;

import macropart1.simtrafficbase.environment.Road;

public interface RoadEntity {
    
    public double getCurrentPosition();

    public Road getRoad();

}
