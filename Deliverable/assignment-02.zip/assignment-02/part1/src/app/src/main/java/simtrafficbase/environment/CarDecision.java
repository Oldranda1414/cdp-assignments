package macropart1.simtrafficbase.environment;

public enum CarDecision {
    ACCELERATING,
    DECELERATING,
    CONSTANT_SPEED
}
