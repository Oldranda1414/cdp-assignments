package macropart1.simtrafficbase.states;

import macropart1.simengine.AbstractStates;
import macropart1.simtrafficbase.environment.RoadsEnv;

public class CarStates extends AbstractStates<RoadsEnv> {
    
    public CarStates(){
        super();
    }
}
