<?php
echo "<!DOCTYPE html>
<html>
    <head>
        <title>Test 1</title>
    </head>

    <body>
        <a href='http://192.168.1.152/Filo/test1.php'>Test link 1</a>
    </body>
</html>";
?>