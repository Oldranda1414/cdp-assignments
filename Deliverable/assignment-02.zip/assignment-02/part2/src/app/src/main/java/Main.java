package macropart2;

import macropart2.View.GUI;
import macropart2.eventloop.WordCounterWithEventLoop;
import macropart2.virtualthreads.WordCounterWithVirtualThreads;
import macropart2.reactive.WordCounterWithReactive;

public class Main {

    public static void main(String[] args) {
        //var wordCounter = new WordCounterWithEventLoop();
        var wordCounter = new WordCounterWithReactive();
        // var wordCounter = new WordCounterWithVirtualThreads(true);
        new GUI(wordCounter).display();
    }

}
