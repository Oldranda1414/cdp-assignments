Dependecies for the server are:
    Python3 with packages:
        flask
        waitress

To launch the server execute the command `python server.py` on the cli.
Starting the assignment from the GUI with url "localhost:8080", word "page" and depth "6" should give a result of 42 occurrences.

