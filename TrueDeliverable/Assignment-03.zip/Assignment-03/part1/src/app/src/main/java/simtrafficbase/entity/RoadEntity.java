package simtrafficbase.entity;

import simtrafficbase.environment.Road;

public interface RoadEntity {
    
    public double getCurrentPosition();

    public Road getRoad();

}
