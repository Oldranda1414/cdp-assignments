package simtrafficbase.states;

import simengine.AbstractStates;
import simtrafficbase.environment.RoadsEnv;

public class CarStates extends AbstractStates<RoadsEnv> {
    
    public CarStates(){
        super();
    }
}
